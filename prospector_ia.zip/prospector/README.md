# Prospector IA — Para Agências de Marketing

Sistema de prospecção automática com IA (Gemini gratuito) para agências de marketing.

## O que faz

- 📡 **RADAR**: Busca empresas no Google Maps pelo nicho e cidade que você definir
- 🔬 **RAIO-X**: Analisa o site de cada lead com IA e gera um briefing comercial
- 🤖 **PILOTO AUTOMÁTICO**: Gera mensagens personalizadas para WhatsApp e conduz a qualificação

---

## Instalação (passo a passo)

### 1. Instale o Python
Baixe em: https://www.python.org/downloads/
- Marque a opção **"Add Python to PATH"** durante a instalação

### 2. Instale as dependências
Abra o **Prompt de Comando** (CMD) e execute:

```
pip install playwright google-generativeai openpyxl requests
playwright install chromium
```

### 3. Obtenha sua chave do Gemini (GRATUITA)
1. Acesse: https://aistudio.google.com/app/apikey
2. Clique em "Create API Key"
3. Copie a chave gerada

### 4. Execute o app
No CMD, navegue até a pasta do projeto e execute:

```
python main.py
```

---

## Como usar

### Passo 1 — Config
- Cole sua chave do Gemini na aba **Config**
- Salve as configurações

### Passo 2 — Radar
- Defina o nicho (ex: "clínica odontológica")
- Defina a cidade e estado
- Configure os filtros desejados
- Clique em **Iniciar Busca**
- O app abrirá o Chrome automaticamente e coletará os leads

### Passo 3 — Leads
- Revise os leads encontrados na tabela
- Clique em **Analisar com IA** para gerar briefings personalizados
- Clique em um lead para ver o briefing

### Passo 4 — WhatsApp
- Configure o nome da agência e serviço
- Defina sua disponibilidade de horários
- Clique em **Abrir WhatsApp Web** e escaneie o QR Code
- Clique em **Iniciar Agente SDR**
- As mensagens personalizadas serão geradas para cada lead
- Revise e envie manualmente (ou automatize com Z-API)

---

## Custo

| Ferramenta | Custo |
|------------|-------|
| Python | Gratuito |
| Playwright (Chromium) | Gratuito |
| Google Gemini API | Gratuito (até 15 req/min, 1M tokens/mês) |
| openpyxl | Gratuito |

**Total: R$ 0,00/mês** para uso moderado.

---

## Estrutura do projeto

```
prospector/
├── main.py              # Interface gráfica principal
├── modules/
│   ├── config.py        # Gerenciamento de configurações
│   ├── radar.py         # Busca de leads no Google Maps
│   ├── raiox.py         # Análise de leads com Gemini
│   └── piloto.py        # Agente SDR + geração de mensagens
└── README.md
```

---

## Observações importantes

- O Google Maps tem proteções contra scraping. Use com responsabilidade e velocidade moderada.
- Para envio automático de WhatsApp, considere usar a **Evolution API** (gratuita e open source).
- As mensagens geradas pela IA devem ser revisadas antes do envio.
- Guarde sua chave do Gemini em local seguro.
