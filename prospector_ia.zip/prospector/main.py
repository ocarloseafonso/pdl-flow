import tkinter as tk
from tkinter import ttk, messagebox
import threading
import json
import os
from modules.radar import RadarModule
from modules.raiox import RaioXModule
from modules.piloto import PilotoModule
from modules.config import ConfigManager

class ProspectorApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Prospector IA — Agência")
        self.root.geometry("1100x720")
        self.root.configure(bg="#0d0d0f")
        self.root.resizable(True, True)

        self.config = ConfigManager()
        self.leads = []

        self._setup_styles()
        self._build_ui()

    def _setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")

        style.configure("Dark.TFrame", background="#0d0d0f")
        style.configure("Card.TFrame", background="#18181b", relief="flat")
        style.configure("Dark.TLabel", background="#0d0d0f", foreground="#e4e4e7", font=("Segoe UI", 10))
        style.configure("Card.TLabel", background="#18181b", foreground="#e4e4e7", font=("Segoe UI", 10))
        style.configure("Title.TLabel", background="#0d0d0f", foreground="#ffffff", font=("Segoe UI", 13, "bold"))
        style.configure("Sub.TLabel", background="#0d0d0f", foreground="#71717a", font=("Segoe UI", 9))
        style.configure("CardTitle.TLabel", background="#18181b", foreground="#ffffff", font=("Segoe UI", 11, "bold"))
        style.configure("CardSub.TLabel", background="#18181b", foreground="#71717a", font=("Segoe UI", 9))
        style.configure("Status.TLabel", background="#0d0d0f", foreground="#22c55e", font=("Segoe UI", 9))

        style.configure("Green.TButton",
            background="#16a34a", foreground="#ffffff",
            font=("Segoe UI", 10, "bold"), borderwidth=0, focuscolor="none", padding=(16, 8))
        style.map("Green.TButton",
            background=[("active", "#15803d"), ("pressed", "#166534")])

        style.configure("Ghost.TButton",
            background="#27272a", foreground="#a1a1aa",
            font=("Segoe UI", 9), borderwidth=0, focuscolor="none", padding=(12, 6))
        style.map("Ghost.TButton",
            background=[("active", "#3f3f46")])

        style.configure("Danger.TButton",
            background="#dc2626", foreground="#ffffff",
            font=("Segoe UI", 9, "bold"), borderwidth=0, focuscolor="none", padding=(12, 6))
        style.map("Danger.TButton",
            background=[("active", "#b91c1c")])

        style.configure("Dark.TEntry",
            fieldbackground="#27272a", foreground="#e4e4e7",
            insertcolor="#e4e4e7", bordercolor="#3f3f46",
            font=("Segoe UI", 10), padding=8)

        style.configure("Dark.TNotebook", background="#0d0d0f", borderwidth=0)
        style.configure("Dark.TNotebook.Tab",
            background="#18181b", foreground="#71717a",
            font=("Segoe UI", 10), padding=(18, 8), borderwidth=0)
        style.map("Dark.TNotebook.Tab",
            background=[("selected", "#0d0d0f")],
            foreground=[("selected", "#ffffff")])

        style.configure("Dark.Treeview",
            background="#18181b", foreground="#e4e4e7",
            fieldbackground="#18181b", rowheight=32,
            font=("Segoe UI", 9), borderwidth=0)
        style.configure("Dark.Treeview.Heading",
            background="#27272a", foreground="#a1a1aa",
            font=("Segoe UI", 9, "bold"), borderwidth=0)
        style.map("Dark.Treeview",
            background=[("selected", "#16a34a")],
            foreground=[("selected", "#ffffff")])

    def _build_ui(self):
        # Top bar
        topbar = ttk.Frame(self.root, style="Dark.TFrame", height=56)
        topbar.pack(fill="x", padx=0, pady=0)
        topbar.pack_propagate(False)

        tk.Label(topbar, text="⚡", bg="#0d0d0f", fg="#16a34a", font=("Segoe UI", 16)).pack(side="left", padx=(20,6), pady=12)
        tk.Label(topbar, text="Prospector IA", bg="#0d0d0f", fg="#ffffff", font=("Segoe UI", 13, "bold")).pack(side="left", pady=12)
        tk.Label(topbar, text="para agências de marketing", bg="#0d0d0f", fg="#52525b", font=("Segoe UI", 9)).pack(side="left", padx=(8,0), pady=16)

        self.status_label = tk.Label(topbar, text="● Pronto", bg="#0d0d0f", fg="#22c55e", font=("Segoe UI", 9))
        self.status_label.pack(side="right", padx=20)

        # Separator
        tk.Frame(self.root, bg="#27272a", height=1).pack(fill="x")

        # Notebook
        self.notebook = ttk.Notebook(self.root, style="Dark.TNotebook")
        self.notebook.pack(fill="both", expand=True, padx=0, pady=0)

        self._build_tab_radar()
        self._build_tab_leads()
        self._build_tab_whatsapp()
        self._build_tab_config()

    # ─── TAB 1: RADAR ────────────────────────────────────────────────────────
    def _build_tab_radar(self):
        frame = ttk.Frame(self.notebook, style="Dark.TFrame")
        self.notebook.add(frame, text="  📡  Radar  ")

        # Left panel — config
        left = tk.Frame(frame, bg="#18181b", width=320)
        left.pack(side="left", fill="y", padx=(16,8), pady=16)
        left.pack_propagate(False)

        tk.Label(left, text="Configurar busca", bg="#18181b", fg="#ffffff",
                 font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=16, pady=(16,4))
        tk.Label(left, text="Defina o perfil do lead ideal", bg="#18181b", fg="#71717a",
                 font=("Segoe UI", 9)).pack(anchor="w", padx=16, pady=(0,14))

        fields = [
            ("Nicho / segmento", "nicho", "Ex: clínica odontológica"),
            ("Cidade", "cidade", "Ex: São Paulo"),
            ("Estado (UF)", "estado", "Ex: SP"),
            ("Avaliação mínima (1-5)", "avaliacao_min", "Ex: 3.5"),
            ("Quantidade de leads", "quantidade", "Ex: 50"),
        ]

        self.radar_vars = {}
        for label, key, placeholder in fields:
            tk.Label(left, text=label, bg="#18181b", fg="#a1a1aa",
                     font=("Segoe UI", 9)).pack(anchor="w", padx=16, pady=(8,2))
            var = tk.StringVar(value=self.config.get(key, ""))
            entry = tk.Entry(left, textvariable=var, bg="#27272a", fg="#e4e4e7",
                            insertbackground="#e4e4e7", font=("Segoe UI", 10),
                            relief="flat", bd=0)
            entry.insert(0, placeholder) if not var.get() else None
            entry.bind("<FocusIn>", lambda e, p=placeholder, v=var: self._clear_placeholder(e, p, v))
            entry.bind("<FocusOut>", lambda e, p=placeholder, v=var: self._restore_placeholder(e, p, v))
            entry.pack(fill="x", padx=16, pady=(0,2), ipady=8)
            self.radar_vars[key] = var

        tk.Frame(left, bg="#27272a", height=1).pack(fill="x", padx=16, pady=16)

        tk.Label(left, text="Filtros avançados", bg="#18181b", fg="#a1a1aa",
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=16, pady=(0,8))

        self.filtro_site = tk.BooleanVar(value=True)
        self.filtro_telefone = tk.BooleanVar(value=True)
        self.filtro_ativo = tk.BooleanVar(value=True)

        for text, var in [
            ("Apenas com site", self.filtro_site),
            ("Apenas com telefone", self.filtro_telefone),
            ("Apenas negócios ativos", self.filtro_ativo),
        ]:
            cb = tk.Checkbutton(left, text=text, variable=var,
                               bg="#18181b", fg="#a1a1aa", selectcolor="#27272a",
                               activebackground="#18181b", activeforeground="#e4e4e7",
                               font=("Segoe UI", 9))
            cb.pack(anchor="w", padx=16)

        tk.Frame(left, bg="#18181b").pack(expand=True)

        btn_buscar = tk.Button(left, text="▶  Iniciar Busca",
                               bg="#16a34a", fg="#ffffff", font=("Segoe UI", 10, "bold"),
                               relief="flat", bd=0, cursor="hand2",
                               command=self._start_radar)
        btn_buscar.pack(fill="x", padx=16, pady=16, ipady=10)

        # Right panel — log
        right = tk.Frame(frame, bg="#0d0d0f")
        right.pack(side="left", fill="both", expand=True, padx=(0,16), pady=16)

        tk.Label(right, text="Log de execução", bg="#0d0d0f", fg="#ffffff",
                 font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(0,8))

        log_frame = tk.Frame(right, bg="#18181b")
        log_frame.pack(fill="both", expand=True)

        self.radar_log = tk.Text(log_frame, bg="#18181b", fg="#22c55e",
                                  font=("Consolas", 9), relief="flat", bd=0,
                                  state="disabled", wrap="word")
        scrollbar = ttk.Scrollbar(log_frame, command=self.radar_log.yview)
        self.radar_log.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.radar_log.pack(fill="both", expand=True, padx=12, pady=12)

        self._log_radar("Sistema iniciado. Configure os parâmetros e clique em Iniciar Busca.\n")

    # ─── TAB 2: LEADS ────────────────────────────────────────────────────────
    def _build_tab_leads(self):
        frame = ttk.Frame(self.notebook, style="Dark.TFrame")
        self.notebook.add(frame, text="  📋  Leads  ")

        # Toolbar
        toolbar = tk.Frame(frame, bg="#0d0d0f")
        toolbar.pack(fill="x", padx=16, pady=(16,8))

        self.leads_count = tk.Label(toolbar, text="0 leads encontrados", bg="#0d0d0f",
                                     fg="#71717a", font=("Segoe UI", 9))
        self.leads_count.pack(side="left")

        tk.Button(toolbar, text="🔍  Analisar com IA",
                  bg="#7c3aed", fg="#ffffff", font=("Segoe UI", 9, "bold"),
                  relief="flat", bd=0, cursor="hand2",
                  command=self._start_raiox).pack(side="right", padx=(8,0), ipadx=12, ipady=6)

        tk.Button(toolbar, text="💬  Enviar para WhatsApp",
                  bg="#16a34a", fg="#ffffff", font=("Segoe UI", 9, "bold"),
                  relief="flat", bd=0, cursor="hand2",
                  command=self._send_to_whatsapp).pack(side="right", padx=(8,0), ipadx=12, ipady=6)

        tk.Button(toolbar, text="📥  Exportar Excel",
                  bg="#27272a", fg="#a1a1aa", font=("Segoe UI", 9),
                  relief="flat", bd=0, cursor="hand2",
                  command=self._export_excel).pack(side="right", ipadx=12, ipady=6)

        # Table
        cols = ("nome", "cidade", "telefone", "site", "avaliacao", "status_ia")
        self.leads_tree = ttk.Treeview(frame, columns=cols, show="headings",
                                        style="Dark.Treeview", selectmode="extended")

        headers = {
            "nome": ("Empresa", 220),
            "cidade": ("Cidade", 120),
            "telefone": ("Telefone", 130),
            "site": ("Site", 160),
            "avaliacao": ("Avaliação", 80),
            "status_ia": ("Status IA", 120),
        }
        for col, (label, width) in headers.items():
            self.leads_tree.heading(col, text=label)
            self.leads_tree.column(col, width=width, minwidth=60)

        vsb = ttk.Scrollbar(frame, orient="vertical", command=self.leads_tree.yview)
        self.leads_tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y", padx=(0,16), pady=(0,16))
        self.leads_tree.pack(fill="both", expand=True, padx=(16,0), pady=(0,16))

        # Detail panel
        detail = tk.Frame(frame, bg="#18181b", height=140)
        detail.pack(fill="x", padx=16, pady=(0,16))
        detail.pack_propagate(False)

        tk.Label(detail, text="Briefing IA do lead selecionado", bg="#18181b",
                 fg="#71717a", font=("Segoe UI", 9)).pack(anchor="w", padx=12, pady=(8,4))

        self.briefing_text = tk.Text(detail, bg="#18181b", fg="#e4e4e7",
                                      font=("Segoe UI", 9), relief="flat", bd=0,
                                      state="disabled", wrap="word", height=4)
        self.briefing_text.pack(fill="both", expand=True, padx=12, pady=(0,8))

        self.leads_tree.bind("<<TreeviewSelect>>", self._on_lead_select)

    # ─── TAB 3: WHATSAPP ─────────────────────────────────────────────────────
    def _build_tab_whatsapp(self):
        frame = ttk.Frame(self.notebook, style="Dark.TFrame")
        self.notebook.add(frame, text="  💬  WhatsApp  ")

        left = tk.Frame(frame, bg="#18181b", width=360)
        left.pack(side="left", fill="y", padx=(16,8), pady=16)
        left.pack_propagate(False)

        tk.Label(left, text="Agente SDR", bg="#18181b", fg="#ffffff",
                 font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=16, pady=(16,4))
        tk.Label(left, text="Configurar o agente de IA que vai prospectar", bg="#18181b",
                 fg="#71717a", font=("Segoe UI", 9)).pack(anchor="w", padx=16, pady=(0,14))

        tk.Label(left, text="Nome da sua agência", bg="#18181b", fg="#a1a1aa",
                 font=("Segoe UI", 9)).pack(anchor="w", padx=16, pady=(8,2))
        self.agencia_var = tk.StringVar(value=self.config.get("agencia", ""))
        tk.Entry(left, textvariable=self.agencia_var, bg="#27272a", fg="#e4e4e7",
                insertbackground="#e4e4e7", font=("Segoe UI", 10),
                relief="flat", bd=0).pack(fill="x", padx=16, ipady=8)

        tk.Label(left, text="Seu serviço principal", bg="#18181b", fg="#a1a1aa",
                 font=("Segoe UI", 9)).pack(anchor="w", padx=16, pady=(12,2))
        self.servico_var = tk.StringVar(value=self.config.get("servico", ""))
        tk.Entry(left, textvariable=self.servico_var, bg="#27272a", fg="#e4e4e7",
                insertbackground="#e4e4e7", font=("Segoe UI", 10),
                relief="flat", bd=0).pack(fill="x", padx=16, ipady=8)

        tk.Label(left, text="Tom da abordagem", bg="#18181b", fg="#a1a1aa",
                 font=("Segoe UI", 9)).pack(anchor="w", padx=16, pady=(12,2))
        self.tom_var = tk.StringVar(value="Consultivo e direto")
        tom_combo = ttk.Combobox(left, textvariable=self.tom_var,
                                  values=["Consultivo e direto", "Formal", "Descontraído", "Urgente"],
                                  state="readonly", font=("Segoe UI", 10))
        tom_combo.pack(fill="x", padx=16)

        tk.Label(left, text="Objetivo da conversa", bg="#18181b", fg="#a1a1aa",
                 font=("Segoe UI", 9)).pack(anchor="w", padx=16, pady=(12,2))
        self.objetivo_var = tk.StringVar(value="Agendar reunião")
        obj_combo = ttk.Combobox(left, textvariable=self.objetivo_var,
                                  values=["Agendar reunião", "Qualificar interesse", "Enviar proposta", "Fechar venda"],
                                  state="readonly", font=("Segoe UI", 10))
        obj_combo.pack(fill="x", padx=16)

        tk.Frame(left, bg="#27272a", height=1).pack(fill="x", padx=16, pady=16)

        tk.Label(left, text="Disponibilidade para reuniões", bg="#18181b", fg="#a1a1aa",
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=16, pady=(0,8))

        dias_frame = tk.Frame(left, bg="#18181b")
        dias_frame.pack(fill="x", padx=16)
        self.dias_vars = {}
        dias = ["Seg", "Ter", "Qua", "Qui", "Sex"]
        for i, dia in enumerate(dias):
            var = tk.BooleanVar(value=True)
            self.dias_vars[dia] = var
            tk.Checkbutton(dias_frame, text=dia, variable=var,
                          bg="#18181b", fg="#a1a1aa", selectcolor="#27272a",
                          activebackground="#18181b", font=("Segoe UI", 9)).grid(row=0, column=i, padx=2)

        horarios_frame = tk.Frame(left, bg="#18181b")
        horarios_frame.pack(fill="x", padx=16, pady=8)
        tk.Label(horarios_frame, text="Das", bg="#18181b", fg="#71717a", font=("Segoe UI", 9)).pack(side="left")
        self.hora_inicio = tk.StringVar(value="09:00")
        tk.Entry(horarios_frame, textvariable=self.hora_inicio, bg="#27272a", fg="#e4e4e7",
                insertbackground="#e4e4e7", font=("Segoe UI", 10), width=6,
                relief="flat", bd=0).pack(side="left", padx=6, ipady=4)
        tk.Label(horarios_frame, text="às", bg="#18181b", fg="#71717a", font=("Segoe UI", 9)).pack(side="left")
        self.hora_fim = tk.StringVar(value="18:00")
        tk.Entry(horarios_frame, textvariable=self.hora_fim, bg="#27272a", fg="#e4e4e7",
                insertbackground="#e4e4e7", font=("Segoe UI", 10), width=6,
                relief="flat", bd=0).pack(side="left", padx=6, ipady=4)

        tk.Frame(left, bg="#18181b").pack(expand=True)

        tk.Button(left, text="🌐  Abrir WhatsApp Web",
                  bg="#075e54", fg="#ffffff", font=("Segoe UI", 10, "bold"),
                  relief="flat", bd=0, cursor="hand2",
                  command=self._open_whatsapp).pack(fill="x", padx=16, pady=(0,8), ipady=10)

        tk.Button(left, text="▶  Iniciar Agente SDR",
                  bg="#16a34a", fg="#ffffff", font=("Segoe UI", 10, "bold"),
                  relief="flat", bd=0, cursor="hand2",
                  command=self._start_sdr).pack(fill="x", padx=16, pady=(0,16), ipady=10)

        # Right — conversation log
        right = tk.Frame(frame, bg="#0d0d0f")
        right.pack(side="left", fill="both", expand=True, padx=(0,16), pady=16)

        tk.Label(right, text="Conversas ativas", bg="#0d0d0f", fg="#ffffff",
                 font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(0,8))

        self.conv_log = tk.Text(right, bg="#18181b", fg="#e4e4e7",
                                 font=("Segoe UI", 9), relief="flat", bd=0,
                                 state="disabled", wrap="word")
        self.conv_log.pack(fill="both", expand=True)
        self._log_conv("Agente SDR aguardando configuração...\n")

    # ─── TAB 4: CONFIG ────────────────────────────────────────────────────────
    def _build_tab_config(self):
        frame = ttk.Frame(self.notebook, style="Dark.TFrame")
        self.notebook.add(frame, text="  ⚙️  Config  ")

        center = tk.Frame(frame, bg="#0d0d0f")
        center.pack(expand=True, fill="both", padx=60, pady=40)

        card = tk.Frame(center, bg="#18181b")
        card.pack(fill="x")

        tk.Label(card, text="Configuração da API", bg="#18181b", fg="#ffffff",
                 font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=24, pady=(24,4))
        tk.Label(card, text="Insira sua chave do Google Gemini para ativar a análise de IA",
                 bg="#18181b", fg="#71717a", font=("Segoe UI", 9)).pack(anchor="w", padx=24, pady=(0,20))

        tk.Label(card, text="Google Gemini API Key", bg="#18181b", fg="#a1a1aa",
                 font=("Segoe UI", 9)).pack(anchor="w", padx=24, pady=(0,4))

        key_frame = tk.Frame(card, bg="#18181b")
        key_frame.pack(fill="x", padx=24, pady=(0,16))

        self.gemini_key = tk.StringVar(value=self.config.get("gemini_key", ""))
        self.key_entry = tk.Entry(key_frame, textvariable=self.gemini_key,
                                   bg="#27272a", fg="#e4e4e7", show="•",
                                   insertbackground="#e4e4e7", font=("Segoe UI", 10),
                                   relief="flat", bd=0)
        self.key_entry.pack(side="left", fill="x", expand=True, ipady=10, padx=(0,8))

        tk.Button(key_frame, text="👁", bg="#27272a", fg="#a1a1aa",
                  relief="flat", bd=0, cursor="hand2",
                  command=self._toggle_key_visibility).pack(side="left", ipadx=10, ipady=10)

        tk.Label(card, text="Obtenha sua chave gratuita em: aistudio.google.com",
                 bg="#18181b", fg="#3b82f6", font=("Segoe UI", 9),
                 cursor="hand2").pack(anchor="w", padx=24, pady=(0,4))

        tk.Frame(card, bg="#27272a", height=1).pack(fill="x", padx=24, pady=16)

        tk.Label(card, text="Modelo", bg="#18181b", fg="#a1a1aa",
                 font=("Segoe UI", 9)).pack(anchor="w", padx=24, pady=(0,4))
        self.modelo_var = tk.StringVar(value="gemini-1.5-flash")
        model_combo = ttk.Combobox(card, textvariable=self.modelo_var,
                                    values=["gemini-1.5-flash", "gemini-1.5-pro", "gemini-2.0-flash"],
                                    state="readonly", font=("Segoe UI", 10), width=30)
        model_combo.pack(anchor="w", padx=24, pady=(0,4))
        tk.Label(card, text="gemini-1.5-flash é gratuito e suficiente para este uso",
                 bg="#18181b", fg="#52525b", font=("Segoe UI", 9)).pack(anchor="w", padx=24, pady=(0,20))

        tk.Button(card, text="💾  Salvar configurações",
                  bg="#16a34a", fg="#ffffff", font=("Segoe UI", 10, "bold"),
                  relief="flat", bd=0, cursor="hand2",
                  command=self._save_config).pack(anchor="w", padx=24, pady=(0,24), ipadx=16, ipady=8)

        # Info card
        info = tk.Frame(center, bg="#18181b")
        info.pack(fill="x", pady=(16,0))

        tk.Label(info, text="📦  Dependências necessárias", bg="#18181b", fg="#ffffff",
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=24, pady=(16,8))

        deps = [
            ("playwright", "Automação do navegador"),
            ("google-generativeai", "API do Gemini"),
            ("openpyxl", "Exportar Excel"),
            ("requests", "Requisições HTTP"),
        ]
        for pkg, desc in deps:
            row = tk.Frame(info, bg="#18181b")
            row.pack(fill="x", padx=24, pady=2)
            tk.Label(row, text=f"  {pkg}", bg="#27272a", fg="#22c55e",
                     font=("Consolas", 9), width=24, anchor="w").pack(side="left", ipady=4, padx=(0,8))
            tk.Label(row, text=desc, bg="#18181b", fg="#71717a",
                     font=("Segoe UI", 9)).pack(side="left")

        tk.Label(info, text="Execute: pip install playwright google-generativeai openpyxl requests && playwright install chromium",
                 bg="#18181b", fg="#52525b", font=("Consolas", 8),
                 wraplength=700).pack(anchor="w", padx=24, pady=(12,16))

    # ─── HELPERS ─────────────────────────────────────────────────────────────
    def _clear_placeholder(self, e, placeholder, var):
        if e.widget.get() == placeholder:
            e.widget.delete(0, "end")
            e.widget.config(fg="#e4e4e7")

    def _restore_placeholder(self, e, placeholder, var):
        if not e.widget.get():
            e.widget.insert(0, placeholder)
            e.widget.config(fg="#52525b")

    def _log_radar(self, msg):
        self.radar_log.config(state="normal")
        self.radar_log.insert("end", msg)
        self.radar_log.see("end")
        self.radar_log.config(state="disabled")

    def _log_conv(self, msg):
        self.conv_log.config(state="normal")
        self.conv_log.insert("end", msg)
        self.conv_log.see("end")
        self.conv_log.config(state="disabled")

    def _set_status(self, text, color="#22c55e"):
        self.status_label.config(text=f"● {text}", fg=color)

    def _toggle_key_visibility(self):
        show = self.key_entry.cget("show")
        self.key_entry.config(show="" if show == "•" else "•")

    def _save_config(self):
        data = {
            "gemini_key": self.gemini_key.get(),
            "modelo": self.modelo_var.get(),
            "agencia": self.agencia_var.get(),
            "servico": self.servico_var.get(),
        }
        self.config.save(data)
        messagebox.showinfo("Salvo", "Configurações salvas com sucesso!")

    def _on_lead_select(self, event):
        selected = self.leads_tree.selection()
        if not selected:
            return
        item = self.leads_tree.item(selected[0])
        nome = item["values"][0]
        lead = next((l for l in self.leads if l.get("nome") == nome), None)
        if lead and lead.get("briefing"):
            self.briefing_text.config(state="normal")
            self.briefing_text.delete("1.0", "end")
            self.briefing_text.insert("1.0", lead["briefing"])
            self.briefing_text.config(state="disabled")

    def _start_radar(self):
        params = {k: v.get() for k, v in self.radar_vars.items()}
        params["filtro_site"] = self.filtro_site.get()
        params["filtro_telefone"] = self.filtro_telefone.get()
        params["filtro_ativo"] = self.filtro_ativo.get()

        self._set_status("Buscando leads...", "#f59e0b")
        self._log_radar(f"\n{'─'*50}\n")
        self._log_radar(f"Iniciando busca: {params.get('nicho')} em {params.get('cidade')}/{params.get('estado')}\n")

        def run():
            radar = RadarModule(self.config.get("gemini_key"), params)
            leads = radar.buscar(callback=self._log_radar)
            self.leads = leads
            self.root.after(0, self._update_leads_table)
            self.root.after(0, lambda: self._set_status(f"{len(leads)} leads encontrados"))

        threading.Thread(target=run, daemon=True).start()

    def _update_leads_table(self):
        for item in self.leads_tree.get_children():
            self.leads_tree.delete(item)
        for lead in self.leads:
            self.leads_tree.insert("", "end", values=(
                lead.get("nome", ""),
                lead.get("cidade", ""),
                lead.get("telefone", ""),
                lead.get("site", ""),
                lead.get("avaliacao", ""),
                lead.get("status_ia", "Aguardando"),
            ))
        self.leads_count.config(text=f"{len(self.leads)} leads encontrados")
        self.notebook.select(1)

    def _start_raiox(self):
        if not self.leads:
            messagebox.showwarning("Atenção", "Nenhum lead encontrado. Execute o Radar primeiro.")
            return
        key = self.config.get("gemini_key")
        if not key:
            messagebox.showwarning("Atenção", "Configure a chave do Gemini na aba Config.")
            return

        self._set_status("Analisando leads com IA...", "#7c3aed")

        def run():
            raiox = RaioXModule(key, self.config.get("modelo", "gemini-1.5-flash"))
            for i, lead in enumerate(self.leads):
                self.root.after(0, lambda i=i: self._set_status(f"Analisando {i+1}/{len(self.leads)}...", "#7c3aed"))
                briefing = raiox.analisar(lead)
                lead["briefing"] = briefing
                lead["status_ia"] = "✅ Analisado"
                self.root.after(0, self._update_leads_table)
            self.root.after(0, lambda: self._set_status("Análise concluída"))

        threading.Thread(target=run, daemon=True).start()

    def _send_to_whatsapp(self):
        selected = self.leads_tree.selection()
        if not selected:
            messagebox.showinfo("Selecione", "Selecione um ou mais leads para enviar.")
            return
        leads_sel = []
        for s in selected:
            nome = self.leads_tree.item(s)["values"][0]
            lead = next((l for l in self.leads if l.get("nome") == nome), None)
            if lead:
                leads_sel.append(lead)
        self.notebook.select(2)
        self._log_conv(f"\n{len(leads_sel)} lead(s) selecionados para abordagem.\n")

    def _open_whatsapp(self):
        import webbrowser
        webbrowser.open("https://web.whatsapp.com")
        self._log_conv("WhatsApp Web aberto no navegador.\n")
        self._log_conv("Após escanear o QR Code, clique em 'Iniciar Agente SDR'.\n")

    def _start_sdr(self):
        key = self.config.get("gemini_key")
        if not key:
            messagebox.showwarning("Atenção", "Configure a chave do Gemini na aba Config.")
            return

        agencia = self.agencia_var.get()
        servico = self.servico_var.get()
        if not agencia or not servico:
            messagebox.showwarning("Atenção", "Preencha o nome da agência e o serviço principal.")
            return

        self._set_status("Agente SDR ativo", "#22c55e")
        self._log_conv(f"\nAgente SDR iniciado para: {agencia}\n")
        self._log_conv(f"Serviço: {servico} | Tom: {self.tom_var.get()} | Objetivo: {self.objetivo_var.get()}\n")
        self._log_conv("─" * 50 + "\n")

        leads_para_abordar = [l for l in self.leads if l.get("status_ia") == "✅ Analisado"]
        if not leads_para_abordar:
            self._log_conv("⚠️  Nenhum lead analisado encontrado. Execute o Raio-X primeiro.\n")
            return

        config_sdr = {
            "agencia": agencia,
            "servico": servico,
            "tom": self.tom_var.get(),
            "objetivo": self.objetivo_var.get(),
            "dias": [d for d, v in self.dias_vars.items() if v.get()],
            "hora_inicio": self.hora_inicio.get(),
            "hora_fim": self.hora_fim.get(),
        }

        def run():
            piloto = PilotoModule(key, self.config.get("modelo", "gemini-1.5-flash"), config_sdr)
            for lead in leads_para_abordar:
                msg = piloto.gerar_mensagem_inicial(lead)
                self.root.after(0, lambda l=lead, m=msg: self._log_conv(
                    f"\n📤 [{l['nome']}]\n{m}\n"
                ))
            self.root.after(0, lambda: self._log_conv("\n✅ Mensagens geradas. Revise e envie manualmente ou use a automação completa.\n"))

        threading.Thread(target=run, daemon=True).start()

    def _export_excel(self):
        if not self.leads:
            messagebox.showwarning("Atenção", "Nenhum lead para exportar.")
            return
        try:
            import openpyxl
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Leads"
            headers = ["Nome", "Cidade", "Telefone", "Site", "Avaliação", "Briefing IA"]
            ws.append(headers)
            for lead in self.leads:
                ws.append([
                    lead.get("nome", ""),
                    lead.get("cidade", ""),
                    lead.get("telefone", ""),
                    lead.get("site", ""),
                    lead.get("avaliacao", ""),
                    lead.get("briefing", ""),
                ])
            path = os.path.join(os.path.expanduser("~"), "Desktop", "leads_prospector.xlsx")
            wb.save(path)
            messagebox.showinfo("Exportado", f"Arquivo salvo em:\n{path}")
        except ImportError:
            messagebox.showerror("Erro", "Instale openpyxl: pip install openpyxl")

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    app = ProspectorApp()
    app.run()
