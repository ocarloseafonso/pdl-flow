import json
import os

CONFIG_FILE = os.path.join(os.path.expanduser("~"), ".prospector_config.json")

class ConfigManager:
    def __init__(self):
        self._data = {}
        self._load()

    def _load(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    self._data = json.load(f)
            except Exception:
                self._data = {}

    def get(self, key, default=""):
        return self._data.get(key, default)

    def save(self, data: dict):
        self._data.update(data)
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(self._data, f, ensure_ascii=False, indent=2)
