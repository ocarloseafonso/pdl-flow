import requests
import json
import time

class RaioXModule:
    """
    Para cada lead, acessa o site e usa Gemini para gerar
    um briefing comercial personalizado.
    """

    def __init__(self, gemini_key: str, modelo: str = "gemini-1.5-flash"):
        self.gemini_key = gemini_key
        self.modelo = modelo
        self.api_url = f"https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent"

    def analisar(self, lead: dict) -> str:
        site_content = ""
        if lead.get("site"):
            site_content = self._fetch_site(lead["site"])

        prompt = self._build_prompt(lead, site_content)
        briefing = self._call_gemini(prompt)
        return briefing

    def _fetch_site(self, url: str) -> str:
        """Tenta buscar o conteúdo do site para análise."""
        if not url.startswith("http"):
            url = "https://" + url
        try:
            resp = requests.get(url, timeout=8, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            })
            text = resp.text
            # Limpar HTML básico
            import re
            text = re.sub(r'<script[^>]*>.*?</script>', '', text, flags=re.DOTALL)
            text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL)
            text = re.sub(r'<[^>]+>', ' ', text)
            text = re.sub(r'\s+', ' ', text).strip()
            return text[:3000]
        except Exception:
            return ""

    def _build_prompt(self, lead: dict, site_content: str) -> str:
        return f"""Você é um analista de negócios especializado em identificar oportunidades de marketing digital para agências.

Analise este lead e gere um briefing comercial conciso:

DADOS DO LEAD:
- Nome: {lead.get('nome', '')}
- Cidade: {lead.get('cidade', '')} / {lead.get('estado', '')}
- Telefone: {lead.get('telefone', '')}
- Site: {lead.get('site', '')}
- Avaliação Google: {lead.get('avaliacao', '')}

CONTEÚDO DO SITE:
{site_content[:2000] if site_content else "Site não acessível ou sem conteúdo identificado."}

TAREFA:
Gere um briefing em 4 partes, sendo DIRETO e OBJETIVO:

1. SEGMENTO: Que tipo de negócio é este? (1 linha)
2. DOR PROVÁVEL: Qual o maior problema de marketing que este negócio provavelmente enfrenta? (1-2 linhas)
3. OPORTUNIDADE: Que serviço de agência faria mais sentido oferecer? (1 linha)
4. GANCHO: Uma frase de abertura poderosa para a primeira mensagem no WhatsApp (1 linha, tom consultivo, sem ser spam)

Responda em português brasileiro. Seja específico, não genérico."""

    def _call_gemini(self, prompt: str) -> str:
        try:
            payload = {
                "contents": [{"parts": [{"text": prompt}]}],
                "generationConfig": {
                    "temperature": 0.7,
                    "maxOutputTokens": 500,
                }
            }
            resp = requests.post(
                f"{self.api_url}?key={self.gemini_key}",
                json=payload,
                timeout=30
            )
            data = resp.json()
            if "candidates" in data:
                return data["candidates"][0]["content"]["parts"][0]["text"]
            elif "error" in data:
                return f"Erro API: {data['error'].get('message', 'Desconhecido')}"
            return "Não foi possível gerar análise."
        except Exception as e:
            return f"Erro ao chamar Gemini: {str(e)}"
