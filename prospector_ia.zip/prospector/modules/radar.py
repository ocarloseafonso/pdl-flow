import time
import re
from typing import Callable, List, Dict

class RadarModule:
    """
    Busca empresas no Google Maps usando Playwright.
    Extrai: nome, telefone, site, endereço, avaliação.
    """

    def __init__(self, gemini_key: str, params: dict):
        self.params = params
        self.gemini_key = gemini_key

    def buscar(self, callback: Callable = None) -> List[Dict]:
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            if callback:
                callback("❌ Playwright não instalado.\nExecute: pip install playwright && playwright install chromium\n")
            return []

        nicho = self.params.get("nicho", "")
        cidade = self.params.get("cidade", "")
        estado = self.params.get("estado", "")
        quantidade = int(self.params.get("quantidade", 20) or 20)
        filtro_site = self.params.get("filtro_site", True)
        filtro_tel = self.params.get("filtro_telefone", True)

        query = f"{nicho} em {cidade} {estado} Brasil"

        if callback:
            callback(f"🔍 Buscando: \"{query}\"\n")
            callback(f"📊 Meta: {quantidade} leads | Filtros: site={filtro_site}, tel={filtro_tel}\n\n")

        leads = []

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=False, slow_mo=100)
            context = browser.new_context(
                viewport={"width": 1280, "height": 800},
                locale="pt-BR"
            )
            page = context.new_page()

            url = f"https://www.google.com/maps/search/{query.replace(' ', '+')}"
            if callback:
                callback(f"🌐 Abrindo Google Maps...\n")

            page.goto(url, wait_until="networkidle", timeout=30000)
            time.sleep(2)

            # Scroll para carregar mais resultados
            results_panel = page.query_selector('div[role="feed"]')
            if not results_panel:
                if callback:
                    callback("⚠️ Não foi possível localizar o painel de resultados.\n")
                browser.close()
                return []

            if callback:
                callback("📜 Carregando resultados...\n")

            for _ in range(min(quantidade // 5, 10)):
                page.evaluate("document.querySelector('div[role=\"feed\"]').scrollBy(0, 800)")
                time.sleep(1.5)

            # Coletar cards
            cards = page.query_selector_all('div[role="feed"] > div > div > a')
            if callback:
                callback(f"✅ {len(cards)} resultados carregados. Extraindo dados...\n\n")

            for i, card in enumerate(cards[:quantidade * 2]):
                if len(leads) >= quantidade:
                    break
                try:
                    card.click()
                    time.sleep(2)

                    nome = self._extract_text(page, 'h1.DUwDvf, h1[data-item-id]') or \
                           self._extract_text(page, '[data-item-id] .fontHeadlineLarge')
                    if not nome:
                        continue

                    telefone = self._extract_info(page, 'data-tooltip="Copiar número de telefone"') or \
                               self._extract_by_aria(page, "phone")
                    site = self._extract_info(page, 'data-tooltip="Abrir o site"') or \
                           self._extract_by_aria(page, "website")
                    endereco = self._extract_info(page, 'data-tooltip="Copiar endereço"')
                    avaliacao = self._extract_text(page, '.F7nice span[aria-hidden="true"]')

                    # Aplicar filtros
                    if filtro_site and not site:
                        continue
                    if filtro_tel and not telefone:
                        continue

                    # Filtro de avaliação
                    min_av = float(self.params.get("avaliacao_min", 0) or 0)
                    if min_av > 0 and avaliacao:
                        try:
                            av_num = float(avaliacao.replace(",", "."))
                            if av_num < min_av:
                                continue
                        except ValueError:
                            pass

                    lead = {
                        "nome": nome.strip(),
                        "telefone": self._limpar_telefone(telefone),
                        "site": site.strip() if site else "",
                        "endereco": endereco.strip() if endereco else "",
                        "cidade": cidade,
                        "estado": estado,
                        "avaliacao": avaliacao or "",
                        "status_ia": "Aguardando",
                        "briefing": "",
                    }

                    leads.append(lead)
                    if callback:
                        callback(f"  [{len(leads):02d}] ✅ {nome[:45]:<45} | {lead['telefone'] or '—'}\n")

                except Exception as e:
                    if callback:
                        callback(f"  ⚠️  Erro ao processar lead: {str(e)[:60]}\n")
                    continue

            browser.close()

        if callback:
            callback(f"\n{'─'*50}\n")
            callback(f"✅ Busca concluída: {len(leads)} leads qualificados encontrados.\n")

        return leads

    def _extract_text(self, page, selector: str) -> str:
        try:
            el = page.query_selector(selector)
            return el.inner_text() if el else ""
        except Exception:
            return ""

    def _extract_info(self, page, tooltip: str) -> str:
        try:
            els = page.query_selector_all(f'[{tooltip}]')
            for el in els:
                text = el.get_attribute("aria-label") or el.inner_text()
                if text:
                    return text
            return ""
        except Exception:
            return ""

    def _extract_by_aria(self, page, kind: str) -> str:
        try:
            mapping = {
                "phone": ["Telefone", "phone", "número"],
                "website": ["Site", "website", "site da"],
            }
            for keyword in mapping.get(kind, []):
                els = page.query_selector_all(f'[aria-label*="{keyword}" i]')
                for el in els:
                    label = el.get_attribute("aria-label") or ""
                    text = re.sub(r"(?i)(telefone|site|website):?\s*", "", label).strip()
                    if text:
                        return text
            return ""
        except Exception:
            return ""

    def _limpar_telefone(self, telefone: str) -> str:
        if not telefone:
            return ""
        return re.sub(r"[^\d+\(\)\-\s]", "", telefone).strip()
