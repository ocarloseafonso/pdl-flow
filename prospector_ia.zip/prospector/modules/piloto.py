import requests
import json
import webbrowser
import urllib.parse
import time

class PilotoModule:
    """
    Agente SDR: gera mensagens personalizadas para WhatsApp
    e gerencia o fluxo de qualificação com IA.
    """

    def __init__(self, gemini_key: str, modelo: str, config_sdr: dict):
        self.gemini_key = gemini_key
        self.modelo = modelo
        self.config = config_sdr
        self.api_url = f"https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent"
        self.historico = {}  # lead_nome -> lista de mensagens

    def gerar_mensagem_inicial(self, lead: dict) -> str:
        """Gera a primeira mensagem personalizada para o lead."""
        prompt = self._prompt_mensagem_inicial(lead)
        mensagem = self._call_gemini(prompt)
        nome = lead.get("nome", "")
        self.historico[nome] = [
            {"role": "assistant", "content": mensagem}
        ]
        return mensagem

    def responder(self, lead_nome: str, resposta_lead: str) -> str:
        """Continua a conversa com base na resposta do lead."""
        if lead_nome not in self.historico:
            return "Lead não encontrado no histórico."

        self.historico[lead_nome].append({"role": "user", "content": resposta_lead})
        prompt = self._prompt_continuacao(lead_nome, resposta_lead)
        resposta_ia = self._call_gemini(prompt)
        self.historico[lead_nome].append({"role": "assistant", "content": resposta_ia})
        return resposta_ia

    def abrir_whatsapp(self, lead: dict, mensagem: str):
        """Abre o WhatsApp Web com a mensagem pré-preenchida."""
        telefone = lead.get("telefone", "")
        # Limpar telefone para formato internacional
        tel_limpo = "".join(filter(str.isdigit, telefone))
        if tel_limpo and not tel_limpo.startswith("55"):
            tel_limpo = "55" + tel_limpo

        msg_encoded = urllib.parse.quote(mensagem)

        if tel_limpo:
            url = f"https://wa.me/{tel_limpo}?text={msg_encoded}"
        else:
            url = f"https://web.whatsapp.com"

        webbrowser.open(url)
        return url

    def _prompt_mensagem_inicial(self, lead: dict) -> str:
        agencia = self.config.get("agencia", "nossa agência")
        servico = self.config.get("servico", "marketing digital")
        tom = self.config.get("tom", "Consultivo e direto")
        objetivo = self.config.get("objetivo", "Agendar reunião")
        briefing = lead.get("briefing", "")

        # Extrair gancho do briefing se disponível
        gancho = ""
        if "GANCHO:" in briefing:
            try:
                gancho = briefing.split("GANCHO:")[1].strip().split("\n")[0]
            except Exception:
                pass

        return f"""Você é um SDR (Sales Development Representative) especializado em prospecção para agências de marketing digital.

CONTEXTO:
- Agência: {agencia}
- Serviço principal: {servico}
- Tom de comunicação: {tom}
- Objetivo: {objetivo}

LEAD:
- Empresa: {lead.get('nome', '')}
- Cidade: {lead.get('cidade', '')}
- Site: {lead.get('site', '')}

BRIEFING DO LEAD:
{briefing}

GANCHO IDENTIFICADO:
{gancho or "Não identificado — crie um relevante"}

TAREFA:
Escreva a PRIMEIRA mensagem de WhatsApp para este lead.

REGRAS OBRIGATÓRIAS:
- Máximo 3 parágrafos curtos
- Não use linguagem de spam ("promoção imperdível", "clique agora", etc.)
- Mencione algo ESPECÍFICO do negócio deles (mostra que pesquisou)
- Tom: {tom}
- Terminar com UMA pergunta simples que seja fácil de responder
- NÃO peça reunião logo na primeira mensagem — qualifique primeiro
- Use emojis com moderação (máximo 2)

Escreva APENAS a mensagem, sem explicações ou introduções."""

    def _prompt_continuacao(self, lead_nome: str, resposta: str) -> str:
        historico = self.historico.get(lead_nome, [])
        historico_txt = "\n".join([
            f"{'VOCÊ' if m['role'] == 'assistant' else 'LEAD'}: {m['content']}"
            for m in historico[-6:]  # últimas 6 mensagens
        ])

        objetivo = self.config.get("objetivo", "Agendar reunião")
        dias = ", ".join(self.config.get("dias", ["Seg", "Ter", "Qua", "Qui", "Sex"]))
        hora_inicio = self.config.get("hora_inicio", "09:00")
        hora_fim = self.config.get("hora_fim", "18:00")

        return f"""Você é um SDR de uma agência de marketing continuando uma conversa de prospecção.

HISTÓRICO DA CONVERSA:
{historico_txt}

NOVA RESPOSTA DO LEAD:
{resposta}

OBJETIVO ATUAL: {objetivo}
DISPONIBILIDADE PARA REUNIÃO: {dias}, das {hora_inicio} às {hora_fim}

TAREFA:
Continue a conversa de forma natural. Avance em direção ao objetivo ({objetivo}).

REGRAS:
- Seja conciso (máximo 2 parágrafos)
- Responda ao que o lead disse antes de avançar
- Se houver objeção, acolha e redirecione
- Se o lead demonstrar interesse, proponha a reunião com datas concretas
- Tom consultivo, nunca pressione

Escreva APENAS a resposta, sem introduções."""

    def _call_gemini(self, prompt: str) -> str:
        try:
            payload = {
                "contents": [{"parts": [{"text": prompt}]}],
                "generationConfig": {
                    "temperature": 0.8,
                    "maxOutputTokens": 600,
                }
            }
            resp = requests.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/{self.modelo}:generateContent?key={self.gemini_key}",
                json=payload,
                timeout=30
            )
            data = resp.json()
            if "candidates" in data:
                return data["candidates"][0]["content"]["parts"][0]["text"]
            elif "error" in data:
                return f"Erro: {data['error'].get('message', 'Desconhecido')}"
            return "Não foi possível gerar resposta."
        except Exception as e:
            return f"Erro: {str(e)}"
